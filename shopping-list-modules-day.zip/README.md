## Shopping List Starter

#### Created for the Thinkful EI Program.

Please reference the startup instructions within your curriculum.